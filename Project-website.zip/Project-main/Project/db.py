# Параметры подключения к базе данных
DB_HOST = "localhost"
DB_NAME = "project"
DB_USER = "postgres"
DB_PASS = "1234"
DB_PORT = "5432"
DB_ADMIN = "postgres"